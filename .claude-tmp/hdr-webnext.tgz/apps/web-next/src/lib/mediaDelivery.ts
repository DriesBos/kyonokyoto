import { imageCdnEnabled } from './env.ts';

const YUTAKA_IMAGE_ORIGIN = 'https://www.yutakakikutakegallery.com';
const YUTAKA_IMAGE_PATH_PREFIX = '/ykgg/wp-content/uploads/';
// trailingSlash: true would 308 the slashless path, and the image CDN should fetch it directly.
const YUTAKA_IMAGE_PROXY_PATH = '/api/yutaka-image/';
const MAX_YUTAKA_IMAGE_BYTES = 12 * 1024 * 1024;
const YUTAKA_IMAGE_TIMEOUT_MS = 10_000;
const EVENT_IMAGE_WIDTHS = [320, 640, 960];
const EVENT_IMAGE_QUALITY = '60';

const rasterImagePathPattern = /\.(?:avif|gif|jpe?g|png|webp)$/i;
const allowedImageContentTypes = new Set([
  'image/avif',
  'image/gif',
  'image/jpeg',
  'image/png',
  'image/webp',
]);

export const validatedYutakaImageUrl = (value: unknown): URL | null => {
  if (typeof value !== 'string' || !value.trim()) return null;

  try {
    const url = new URL(value);
    if (url.protocol !== 'https:') return null;
    if (url.origin !== YUTAKA_IMAGE_ORIGIN) return null;
    if (url.username || url.password || url.port) return null;
    if (!url.pathname.startsWith(YUTAKA_IMAGE_PATH_PREFIX)) return null;
    if (!rasterImagePathPattern.test(url.pathname)) return null;
    url.search = '';
    url.hash = '';
    return url;
  } catch {
    return null;
  }
};

export const safeEventImageSource = (value: string | null): string | null => {
  const upstream = validatedYutakaImageUrl(value);
  if (upstream) return `${YUTAKA_IMAGE_PROXY_PATH}?url=${encodeURIComponent(upstream.href)}`;

  if (typeof value !== 'string') return null;
  // Venue photos we host ourselves (public/venues) when the origin can't be fetched by the CDN.
  if (/^\/(?!\/)[\w./-]+$/.test(value) && rasterImagePathPattern.test(value)) return value;
  try {
    const url = new URL(value);
    if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.port) {
      return null;
    }
    url.hash = '';
    // Node leaves | and ^ raw in paths while browsers percent-encode them; encode them here so
    // server and client render the same src (no hydration mismatch).
    return url.href.replace(/[|^]/g, encodeURIComponent);
  } catch {
    return null;
  }
};

// The CDN fetches http:// origins server-side; served directly they are mixed content the CSP
// (img-src https:) blocks, so try https instead.
const directImageSource = (source: string) => source.replace(/^http:\/\//, 'https://');

const netlifyImageUrl = (source: string, width: number) =>
  `/.netlify/images?${new URLSearchParams({
    url: source,
    w: String(width),
    q: EVENT_IMAGE_QUALITY,
  })}`;

export const eventMediaDeliveryUrl = (
  value: string | null,
  useImageCdn = imageCdnEnabled(),
): string | null => {
  const source = safeEventImageSource(value);
  if (!source) return null;
  return useImageCdn ? netlifyImageUrl(source, 640) : directImageSource(source);
};

export const eventMediaDeliverySrcSet = (
  value: string | null,
  useImageCdn = imageCdnEnabled(),
): string | null => {
  const source = safeEventImageSource(value);
  if (!source || !useImageCdn) return null;
  return EVENT_IMAGE_WIDTHS.map((width) => `${netlifyImageUrl(source, width)} ${width}w`).join(
    ', ',
  );
};

// Social cards need an absolute URL; origin is the site origin for CDN and self-hosted paths.
export const eventShareImageUrl = (
  value: string | null,
  origin: string,
  useImageCdn = imageCdnEnabled(),
): string | null => {
  const source = safeEventImageSource(value);
  if (!source) return null;
  const url = useImageCdn ? netlifyImageUrl(source, 1200) : directImageSource(source);
  return new URL(url, origin).href;
};

export const landingMediaDeliveryUrl = (
  value: string | null,
  width: number,
  height: number,
  useNetlifyImageCdn: boolean,
): string | null => {
  const source = safeEventImageSource(value);
  if (!source) return null;
  if (!useNetlifyImageCdn) return directImageSource(source);

  return `/.netlify/images?${new URLSearchParams({
    url: source,
    w: String(width),
    h: String(height),
    fit: 'cover',
    position: 'center',
    q: '60',
  })}`;
};

const noStoreResponse = (body: string, status: number) =>
  new Response(body, {
    status,
    headers: {
      'Cache-Control': 'no-store',
      'Content-Type': 'text/plain; charset=utf-8',
      'X-Content-Type-Options': 'nosniff',
    },
  });

const cancelResponseBody = async (response: Response) => {
  await response.body?.cancel().catch(() => undefined);
};

const readImageBodyWithinLimit = async (
  response: Response,
): Promise<Uint8Array<ArrayBuffer> | null> => {
  const reader = response.body?.getReader();
  if (!reader) return new Uint8Array();

  const chunks: Uint8Array[] = [];
  let totalBytes = 0;

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      if (!value?.byteLength) continue;

      totalBytes += value.byteLength;
      if (totalBytes > MAX_YUTAKA_IMAGE_BYTES) {
        await reader.cancel().catch(() => undefined);
        return null;
      }
      chunks.push(value);
    }
  } catch (error) {
    await reader.cancel().catch(() => undefined);
    throw error;
  }

  const body = new Uint8Array(totalBytes);
  let offset = 0;
  for (const chunk of chunks) {
    body.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return body;
};

export const proxyYutakaImage = async (
  request: Request,
  fetchImpl: typeof fetch = fetch,
): Promise<Response> => {
  const requestedUrl = new URL(request.url).searchParams.get('url');
  const upstreamUrl = validatedYutakaImageUrl(requestedUrl);
  if (!upstreamUrl || requestedUrl !== upstreamUrl.href) {
    return noStoreResponse('Invalid image URL', 400);
  }

  let upstreamResponse: Response;
  try {
    upstreamResponse = await fetchImpl(upstreamUrl, {
      headers: {
        Accept: 'image/avif,image/webp,image/png,image/jpeg,image/gif',
        Referer: `${YUTAKA_IMAGE_ORIGIN}/`,
        'User-Agent': 'kyo-no-kyoto-media-proxy/1.0',
      },
      redirect: 'manual',
      signal: AbortSignal.timeout(YUTAKA_IMAGE_TIMEOUT_MS),
    });
  } catch {
    return noStoreResponse('Upstream image unavailable', 502);
  }

  if (!upstreamResponse.ok || (upstreamResponse.status >= 300 && upstreamResponse.status < 400)) {
    await cancelResponseBody(upstreamResponse);
    return noStoreResponse('Upstream image unavailable', 502);
  }

  const contentType = upstreamResponse.headers.get('Content-Type')?.split(';', 1)[0].trim() ?? '';
  if (!allowedImageContentTypes.has(contentType.toLowerCase())) {
    await cancelResponseBody(upstreamResponse);
    return noStoreResponse('Upstream response is not a supported image', 502);
  }

  const contentLength = Number(upstreamResponse.headers.get('Content-Length'));
  if (Number.isFinite(contentLength) && contentLength > MAX_YUTAKA_IMAGE_BYTES) {
    await cancelResponseBody(upstreamResponse);
    return noStoreResponse('Upstream image is too large', 502);
  }

  let body: Uint8Array<ArrayBuffer> | null;
  try {
    body = await readImageBodyWithinLimit(upstreamResponse);
  } catch {
    return noStoreResponse('Upstream image unavailable', 502);
  }
  if (!body) {
    return noStoreResponse('Upstream image is too large', 502);
  }

  return new Response(body, {
    status: 200,
    headers: {
      'Cache-Control': 'public, max-age=86400, stale-while-revalidate=604800',
      'Content-Length': String(body.byteLength),
      'Content-Type': contentType,
      'Netlify-CDN-Cache-Control':
        'public, durable, max-age=604800, stale-while-revalidate=2592000',
      'Netlify-Vary': 'query=url',
      'X-Content-Type-Options': 'nosniff',
    },
  });
};
